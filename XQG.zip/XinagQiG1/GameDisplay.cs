﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace XinagQiG1
{
    class GameDisplay
    {


        public static GameBoard GameB = new GameBoard();

        static Rook b_Rook31 = new Rook(-31, GameB);
        static Rook b_Rook32 = new Rook(-32, GameB);

        static Knight b_Knight41 = new Knight(-41, GameB);
        static Knight b_Knight42 = new Knight(-42, GameB);

        static Minister b_Minister51 = new Minister(-51, GameB);
        static Minister b_Minister52 = new Minister(-52, GameB);

        static Guard b_Guard61 = new Guard(-61, GameB);
        static Guard b_Guard62 = new Guard(-62, GameB);

        static King b_King7 = new King(-7, GameB);

        static Cannon b_Cannon21 = new Cannon(-21, GameB);
        static Cannon b_Cannon22 = new Cannon(-22, GameB);

        static Pawn b_Pawn11 = new Pawn(-11, GameB);
        static Pawn b_Pawn12 = new Pawn(-12, GameB);
        static Pawn b_Pawn13 = new Pawn(-13, GameB);
        static Pawn b_Pawn14 = new Pawn(-14, GameB);
        static Pawn b_Pawn15 = new Pawn(-15, GameB);


        //红 Red
        static Rook r_Rook31 = new Rook(31, GameB);
        static Rook r_Rook32 = new Rook(32, GameB);

        static Knight r_Knight41 = new Knight(41, GameB);
        static Knight r_Knight42 = new Knight(42, GameB);

        static Minister r_Minister51 = new Minister(51, GameB);
        static Minister r_Minister52 = new Minister(52, GameB);

        static Guard r_Guard61 = new Guard(61, GameB);
        static Guard r_Guard62 = new Guard(62, GameB);

        static King r_King7 = new King(7, GameB);

        static Cannon r_Cannon21 = new Cannon(21, GameB);
        static Cannon r_Cannon22 = new Cannon(22, GameB);

        static Pawn r_Pawn11 = new Pawn(11, GameB);
        static Pawn r_Pawn12 = new Pawn(12, GameB);
        static Pawn r_Pawn13 = new Pawn(13, GameB);
        static Pawn r_Pawn14 = new Pawn(14, GameB);
        static Pawn r_Pawn15 = new Pawn(15, GameB);
        //put all the pieces in variable pie
        public static Piece[] pie = {   //16*2=32         
            b_Rook31, b_Rook32,b_Knight41,b_Knight42,b_Minister51,b_Minister52, //6
            b_Guard61,b_Guard62,b_King7,b_Cannon21,b_Cannon22,b_Pawn11,b_Pawn12, //7
            b_Pawn13,b_Pawn14,b_Pawn15, //3
            r_Rook31, r_Rook32,r_Knight41,r_Knight42,r_Minister51,r_Minister52,
            r_Guard61,r_Guard62,r_King7,r_Cannon21,r_Cannon22,r_Pawn11,r_Pawn12,
            r_Pawn13,r_Pawn14,r_Pawn15
        };
        //转换position给pie
        static public int ChangeTopie(int position)
        {
            if (position == -31)
                return 0;
            else if (position == -32)
                return 1;
            else if (position == -41)
                return 2;
            else if (position == -42)
                return 3;
            else if (position == -51)
                return 4;
            else if (position == -52)
                return 5;
            else if (position == -61)
                return 6;
            else if (position == -62)
                return 7;
            else if (position == -7)//b_King7
                return 8;
            else if (position == -21)
                return 9;
            else if (position == -22)
                return 10;
            else if (position == -11)
                return 11;
            else if (position == -12)
                return 12;
            else if (position == -13)
                return 13;
            else if (position == -14)
                return 14;
            else if (position == -15)
                return 15;
            else if (position == 31)//////////////////////////
                return 16;
            else if (position == 32)
                return 17;
            else if (position == 41)
                return 18;
            else if (position == 42)
                return 19;
            else if (position == 51)
                return 20;
            else if (position == 52)
                return 21;
            else if (position == 61)
                return 22;
            else if (position == 62)
                return 23;
            else if (position == 7)//b_King7
                return 24;
            else if (position == 21)
                return 25;
            else if (position == 22)
                return 26;
            else if (position == 11)
                return 27;
            else if (position == 12)
                return 28;
            else if (position == 13)
                return 29;
            else if (position == 14)
                return 30;
            else if (position == 15)
                return 31;



            return 0;
        }

        private Window window = new Window();

        private Button Choose = new Button();
        public GameDisplay(Window win)
        {
            this.window = win;
        }

        //初始化棋盘以及生成棋子
        static StackPanel stackpanel = new StackPanel();
        static Grid grid = new Grid();
        static TextBlock Side = new TextBlock();
        static TextBlock Rounds = new TextBlock();
        public void Initialize_chessboard()
        {
            int num_Rows = 10;
            int num_Columns = 9;
            stackpanel.Orientation = Orientation.Horizontal;
            //Setting grid
            ImageBrush grid_bg = new ImageBrush();
            //D:/桌面/XQG/XinagQiG1/images/
            grid_bg.ImageSource = new BitmapImage(new Uri("images/Board.png", UriKind.Relative));
            grid.Background = grid_bg;
            grid.Width = 1000;
            grid.Height = 900;
            //grid.ShowGridLines=true;
            StackPanel Sidebar = new StackPanel();
            Sidebar.Orientation = Orientation.Vertical;
            ImageBrush Sidebar_bg = new ImageBrush();
            Sidebar_bg.ImageSource = new BitmapImage(new Uri("images/Sidebar_bg.jpg", UriKind.Relative));
            Sidebar.Background = Sidebar_bg;
            TextBlock blanck = new TextBlock();
            blanck.Height = 200;
            blanck.FontSize = 30;
            blanck.Text = "";

            TextBlock PlayerSide = new TextBlock();
            PlayerSide.Width = 200;
            PlayerSide.Foreground = Brushes.Black;
            PlayerSide.FontSize = 30;
            PlayerSide.Text = "Side:";

            
            Side.Width = 200;
            Side.Foreground = Brushes.Red;
            Side.FontSize = 50;
            Side.Text = "Red";

            
            Rounds.Width = 200;
            Rounds.Foreground = Brushes.Black;
            Rounds.FontSize = 30;
            Rounds.Text = "Rounds: " + 1;

            TextBlock blanck2 = new TextBlock();
            blanck2.Height = 400;
            blanck2.FontSize = 30;
            blanck2.Text = "";

            Button Start = new Button();
            Start.FontSize = 30;
            Start.Content = "Reset Game";
            Start.Background = null;
            Start.BorderBrush = null;
            Start.Click += Start_click;

            
            Sidebar.Children.Add(PlayerSide);
            Sidebar.Children.Add(Side);
            Sidebar.Children.Add(blanck);
            Sidebar.Children.Add(Rounds);
            Sidebar.Children.Add(blanck2);
            Sidebar.Children.Add(Start);

            stackpanel.Children.Add(grid);
            stackpanel.Children.Add(Sidebar);

            window.Content = stackpanel;

            window.Width = 1200;
            window.Height = 900;

            for (int Column = 0; Column < num_Columns; Column++)
            {
                ColumnDefinition colDef = new ColumnDefinition();
                //colDef.Width = GridLength.Auto;
                grid.ColumnDefinitions.Add(colDef);
            }

            for (int Row = 0; Row < num_Rows; Row++)
            {
                RowDefinition rowDef = new RowDefinition();
                //rowDef.Height = GridLength.Auto;
                grid.RowDefinitions.Add(rowDef);
            }
            RowDefinition rowDef2 = new RowDefinition();
            grid.RowDefinitions.Add(rowDef2);

            for (int Row = 0; Row < num_Rows; Row++)
            {
                for (int Column = 0; Column < num_Columns; Column++)
                {
                    Button btn = new Button();
                    btn.Tag = new Point(Row, Column);
                    btn.Width = 80;
                    btn.Height = 80;
                    btn.Background = null;
                    btn.BorderBrush = null;
                    btn.BorderThickness = new Thickness(5, 5, 5, 5);
                    btn.Click += btn_Click;
                    if (GameB.gameboard[Row, Column] == 0)
                    {
                        //画没棋子的空白位置 draw the positons where have not pieces                     
                        btn.Content = null;

                        Grid.SetRow(btn, Row);
                        Grid.SetColumn(btn, Column);
                        grid.Children.Add(btn);
                    }
                    else
                    {
                        //画棋子 draw pieces

                        if (Row > 4)
                        {
                            btn.Foreground = Brushes.Red;
                            //btn.Content = pie[ChangeTopie(GameB.gameboard[Row, Column])].ToString();
                            btn.Background = Pieces_images(GameB.gameboard[Row, Column]);
                        }
                        else
                        {
                            btn.Foreground = Brushes.Black;
                            //btn.Content = pie[ChangeTopie(GameB.gameboard[Row, Column])].ToString();
                            btn.Background = Pieces_images(GameB.gameboard[Row, Column]);
                        }
                        
                        Grid.SetRow(btn, Row);
                        Grid.SetColumn(btn, Column);
                        grid.Children.Add(btn);
                    }
                }
            }
        }

        //轮换双方棋子
        static int count = 0;
        static Boolean counter(int a)
        {
            if (count % 2 == 1)
                return false;
            else
                return true;

        }
        static bool Is_Choose = false;
        public void btn_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            Point btn_point = (Point)btn.Tag;
            int btn_position = ChangeTopie(GameB.gameboard[btn_point.getX(), btn_point.getY()]);
            //If player choose right piece
            if (!Is_Choose)
            {
                if (btn.Background != null && pie[btn_position].GetMove() != null)
                {
                    //If player choose a red piece
                    if (GameB.gameboard[btn_point.getX(), btn_point.getY()] > 0 && counter(count) == true
                        //OR if player choose a black piece
                        || GameB.gameboard[btn_point.getX(), btn_point.getY()] < 0 && counter(count) == false)
                    {
                        //Save the button in Choose
                        Choose = btn;
                        Is_Choose = true;
                        //Show where button can move
                        Show_ValidMoves(btn_position);
                    }
                    if (GameB.gameboard[btn_point.getX(), btn_point.getY()] > 0 && counter(count) == false
                        //OR if player choose a black piece
                        || GameB.gameboard[btn_point.getX(), btn_point.getY()] < 0 && counter(count) == true)
                    {
                        MessageBox.Show("Wrong color choice!");
                    }
                }
            }
            //When player choose a destination
            else
            {
                Point Chose_point = (Point)Choose.Tag;
                int Row = Chose_point.getX();
                int Column = Chose_point.getY();
                int Chose_position = ChangeTopie(GameB.gameboard[Row, Column]);
                Point destination = (Point)btn.Tag;
                //There are destination the piece can move
                if (pie[Chose_position].ValidMoves(destination))
                {
                    //Judge if King is dead
                    GameOver(btn);
                    //red
                    if (GameB.gameboard[Row, Column] > 0 && counter(count) == true)
                    {
                        pie[Chose_position].setPosition(destination);
                        btn.Background = Choose.Background;
                        count = count + 1;
                        Side.Foreground = Brushes.Black;
                        Side.Text = "Black";

                    }//black
                    else if (GameB.gameboard[Row, Column] < 0 && counter(count) == false)
                    {
                        pie[Chose_position].setPosition(destination);
                        btn.Background = Choose.Background;
                        count = count + 1;
                        Side.Foreground = Brushes.Red;
                        Side.Text = "Red";
                    }
                    Is_Choose = false;
                    Choose.Background = null;
                    Rounds.Text = "Rounds: "+ (count+1);
                    //Initialize button color
                    Color_Initialize();
                }
                else if(pie[Chose_position] == pie[btn_position])
                {
                    Is_Choose = false;
                    Color_Initialize();
                }
                else
                {
                    MessageBox.Show("Wrong destination choice!");
                }
            }
        }

        //Show where button can move
        public void Show_ValidMoves(int btn_position)
        {
            Button button;
            int count = grid.Children.Count;
            // 遍历Grid下所有控件 
            for (int i = 0; i < count; i++)
            {
                button = grid.Children[i] as Button;
                Point[] p5 = pie[btn_position].GetMove();
                Point button_point = (Point)button.Tag;
                for (int j = 0; j < p5.Length; j++)
                {
                    if (button != null && button_point.Point_Equal(p5[j]))
                    {
                        ImageBrush b1 = new ImageBrush();
                        b1.ImageSource = new BitmapImage(new Uri("images/Frame.png", UriKind.Relative));
                        button.BorderBrush = b1;
                    }
                }
            }
        }
        //Initialize button color
        public void Color_Initialize()
        {
            Button button;
            int count = grid.Children.Count;
            // 遍历Grid下所有控件 
            for (int i = 0; i < count; i++)
            {
                button = grid.Children[i] as Button;
                if (button != null && button.BorderBrush != null)
                {
                    button.BorderBrush = null;
                }
            }
        }
        //Judge if King is dead
        public void GameOver(Button button)
        {
            Point btn_point = (Point)button.Tag;
            int btn_position = GameB.gameboard[btn_point.getX(), btn_point.getY()];
            if (btn_position == 7 || btn_position == -7)
            {
                Button GameOver = new Button();
                GameOver.Content = "GameOver";
                GameOver.FontSize = 50;
                GameOver.Click += btn_GameOver;
                window.Content = GameOver;
                
            }

        }
        public void btn_GameOver(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        public void Start_click(object sender, EventArgs e)
        {
            /*Process p = new Process();
            p.StartInfo.FileName = System.AppDomain.CurrentDomain.BaseDirectory + "XinagQiG1.exe";
            p.StartInfo.UseShellExecute = false;
            p.Start();
            Application.Current.Shutdown();
            p.Close();*/
            System.Reflection.Assembly.GetEntryAssembly();
            string startpath = System.IO.Directory.GetCurrentDirectory();
            System.Diagnostics.Process.Start(startpath + "\\XinagQiG1.exe"); //此处修改为自己的应用程序名称
            Application.Current.Shutdown();
        }
        public static ImageBrush Pieces_images(int position)
        {
            ImageBrush Piece_background = new ImageBrush();

            if (position == -31)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Rook.png", UriKind.Relative));
            else if (position == -32)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Rook.png", UriKind.Relative));
            else if (position == -41)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Knight.png", UriKind.Relative));
            else if (position == -42)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Knight.png", UriKind.Relative));
            else if (position == -51)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Minister.png", UriKind.Relative));
            else if (position == -52)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Minister.png", UriKind.Relative));
            else if (position == -61)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Guard.png", UriKind.Relative));
            else if (position == -62)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Guard.png", UriKind.Relative));
            else if (position == -7)//b_King7
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_King.png", UriKind.Relative));
            else if (position == -21)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Cannon.png", UriKind.Relative));
            else if (position == -22)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Cannon.png", UriKind.Relative));
            else if (position == -11)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Pawn.png", UriKind.Relative));
            else if (position == -12)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Pawn.png", UriKind.Relative));
            else if (position == -13)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Pawn.png", UriKind.Relative));
            else if (position == -14)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Pawn.png", UriKind.Relative));
            else if (position == -15)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Black_Pawn.png", UriKind.Relative));
            else if (position == 31)//////////////////////////
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Rook.png", UriKind.Relative));
            else if (position == 32)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Rook.png", UriKind.Relative));
            else if (position == 41)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Knight.png", UriKind.Relative));
            else if (position == 42)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Knight.png", UriKind.Relative));
            else if (position == 51)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Minister.png", UriKind.Relative));
            else if (position == 52)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Minister.png", UriKind.Relative));
            else if (position == 61)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Guard.png", UriKind.Relative));
            else if (position == 62)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Guard.png", UriKind.Relative));
            else if (position == 7)//b_King7
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_King.png", UriKind.Relative));
            else if (position == 21)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Cannon.png", UriKind.Relative));
            else if (position == 22)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Cannon.png", UriKind.Relative));
            else if (position == 11)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Pawn.png", UriKind.Relative));
            else if (position == 12)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Pawn.png", UriKind.Relative));
            else if (position == 13)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Pawn.png", UriKind.Relative));
            else if (position == 14)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Pawn.png", UriKind.Relative));
            else if (position == 15)
                Piece_background.ImageSource = new BitmapImage(new Uri("images/Red_Pawn.png", UriKind.Relative));


            return Piece_background;
        }

    }
}
   
