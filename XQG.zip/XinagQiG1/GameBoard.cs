﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XinagQiG1
{
    public class GameBoard
    {
        public int[,] gameboard = new int[10, 9] {
        { -31,-41,-51,-61, -7,-62,-52,-42,-32},
        {   0,  0,  0,  0,  0,  0,  0,  0,  0},
        {   0,-21,  0,  0,  0,  0,  0,-22,  0},
        {  -11, 0,-12,  0,-13,  0,-14,  0,-15},
        {   0,  0,  0,  0,  0,  0,  0,  0,  0},

        {   0,  0,  0,  0,  0,  0,  0,  0,  0},
        {  11,  0, 12,  0, 13,  0, 14,  0, 15},
        {   0, 21,  0,  0,  0,  0,  0, 22,  0},
        {   0,  0,  0,  0,  0,  0,  0,  0,  0},
        {  31, 41, 51, 61,  7, 62, 52, 42, 32}};

    }
}
